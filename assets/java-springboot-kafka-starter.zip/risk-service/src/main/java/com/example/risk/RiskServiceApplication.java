package com.example.risk;
import org.springframework.boot.SpringApplication; import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication public class RiskServiceApplication {
  public static void main(String[] args){ SpringApplication.run(RiskServiceApplication.class, args); }
}
